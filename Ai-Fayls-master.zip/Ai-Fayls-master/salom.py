print("salom")
