# praktikum_datasets
Datasets for Data Science and AI Praktikum
